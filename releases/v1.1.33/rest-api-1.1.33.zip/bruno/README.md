# StayTuned API test collection

Requests for every endpoint of the StayTuned REST API, for [Bruno](https://www.usebruno.com/) (free, open source). The full reference is `REST_API.md`.

## Getting started

1. Install Bruno and choose **Open Collection**, then select this `bruno` folder.
2. Copy `.env.example` to `.env` and put the tuner's IP address in it (shown on the tuner: ⚙ → About, `IP:`):
   ```
   TUNER_IP=192.168.1.100
   ```
3. Pick the **By IP** environment (top right) and run **1 Status → Get status**.

The **StayTuned** environment uses `http://staytuned.local` instead and needs no setup, but on Windows each request can take about 5 s for the `.local` name lookup.

Requests that change something on the tuner (move the motors, write flash, switch modes) are marked ⚠ in their docs.
